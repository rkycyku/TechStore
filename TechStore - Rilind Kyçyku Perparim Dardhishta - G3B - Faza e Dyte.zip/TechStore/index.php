<?php
// Pershkak se faqet kryesore gjenden ne folderin php/pages kjo sherben qe te ridrejtoheni automatikisht ne faqen kryesore
echo '<script>document.location="./php/pages/index.php";</script>'

?>

