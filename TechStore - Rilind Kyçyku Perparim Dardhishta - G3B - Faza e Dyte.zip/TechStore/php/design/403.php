<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Error 403 | Tech Store</title>
  <link rel="shortcut icon" href="../../img/web/favicon.ico" />
  <link rel="stylesheet" href="../../css/errorPage.css" />
</head>

<body>
  <?php include './header.php' ?>

  <div class="about">
    <h3 class="title">403 | Nuk keni akses per tu qasur ne kete faqe!</h3>
  </div>

  <?php include './footer.php' ?>
</body>

</html>