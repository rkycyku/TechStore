<?php
echo '<script>document.location="../pages/produktet.php?kerko=' . $_POST['kerkimi'] . '"</script>';
?>