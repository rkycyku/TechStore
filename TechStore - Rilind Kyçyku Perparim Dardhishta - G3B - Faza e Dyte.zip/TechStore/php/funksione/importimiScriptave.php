<?php
echo '
<script src="../../js/slider.js"></script>
<script src="../../js/validimiFormave.js"></script>
<script src="../../js/mbyllMesazhin.js"></script>
'
    ?>